from django.db import models

# Create your models here.

class Plants(models.Model):
    name=models.CharField(max_length=128,unique=True)
    recommend=models.TextField()
    par1=models.FloatField()
    par2 = models.FloatField()
    par3 = models.FloatField()
    par4 = models.FloatField()
    par5 = models.FloatField()
    par6 = models.FloatField()

    def _str_(self):
        return self.name




