from django.shortcuts import render
from django.shortcuts import redirect
from . import models

# Create your views here.
def index(request):
    pass
    return render(request, 'page/index.html')
def plant(request):
    if request.method=='POST':
        plant_name=request.POST.get('search')
        print(plant_name)
        if plant_name=="麦冬":
            return render(request, 'page/plant_type_1.html')
        if plant_name=="佛甲草":
            return render(request, 'page/plant_type_2.html')
        if plant_name=="狗牙根":
            return render(request, 'page/plant_type_3.html')
        if plant_name=="牛筋草":
            return render(request, 'page/plant_type_4.html')
        if plant_name=="细叶芒":
            return render(request, 'page/plant_type_5.html')
        if plant_name=="栗褐苔草":
            return render(request, 'page/plant_type_6.html')
        if plant_name=="牛鞭草":
            return render(request, 'page/plant_type_7.html')
        if plant_name=="高羊茅":
            return render(request, 'page/plant_type_8.html')
        if plant_name=="多年生黑麦":
            return render(request, 'page/plant_type_9.html')
        else:
            message = '未查到内容'
            return render(request, 'page/miss_search.html')
    return render(request, 'page/plant.html')
def plant_type_1(request):
    pass
    return render(request, 'page/plant_type_1.html')
def plant_type_2(request):
    pass
    return render(request, 'page/plant_type_2.html')
def plant_type_3(request):
    pass
    return render(request, 'page/plant_type_3.html')
def plant_type_4(request):
    pass
    return render(request, 'page/plant_type_4.html')
def plant_type_5(request):
    pass
    return render(request, 'page/plant_type_5.html')
def plant_type_6(request):
    pass
    return render(request, 'page/plant_type_6.html')
def plant_type_7(request):
    pass
    return render(request, 'page/plant_type_7.html')
def plant_type_8(request):
    pass
    return render(request, 'page/plant_type_8.html')
def plant_type_9(request):
    pass
    return render(request, 'page/plant_type_9.html')
def miss_search(request):
    pass
    return render(request, 'page/miss_search.html')